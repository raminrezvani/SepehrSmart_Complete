// const { defineConfig } = require('@vue/cli-service')
//
// export default defineConfig({
//   // ...
//   resolve: {
//     mainFields: [
//       'browser',
//       'module',
//       'main',
//       'jsnext:main',
//       'jsnext'
//     ]
//   }
// })