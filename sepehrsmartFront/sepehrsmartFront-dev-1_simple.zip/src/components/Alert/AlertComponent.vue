<template>
<div class="modal fade" id="alertCustomModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">ملاحظات</h1>
      </div>
      <div class="modal-body" style="line-height: 2">
        <ul>
          <li>تمامی قیمت ها با احتساب کسر کمیسیون و به صورت نت میباشد</li>
          <li class="mt-2">همکار گرامی این سامانه یک سیستم تثبیت کننده و مشاور میباشد درجهت بهینه سازی و بالابردن قدرت و دقت فروش کارشناس تور</li>
        </ul>
      </div>
    </div>
  </div>
</div>
</template>

<script>
export default {
  name: "AlertComponent"
}
</script>

<style scoped>

</style>