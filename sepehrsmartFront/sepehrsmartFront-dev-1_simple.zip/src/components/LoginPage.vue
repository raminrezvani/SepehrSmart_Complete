<template>
  <section class="vh-100 overflow-hidden">
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-6 text-black">
          <div class="d-flex align-items-center h-custom-2 px-5 ms-xl-4 mt-5 pt-5 pt-xl-0 mt-xl-n5">
            <div style="width: 30rem;">
              <h1 class="text-center">ورود</h1>
              <hr>
              <div class="form-outline mb-4">
                <label class="form-label" for="form2Example18">نام کاربری</label>
                <input type="text" id="form2Example18" class="form-control form-control-lg" v-model="login.username"/>
              </div>
              <div class="form-outline mb-4">
                <label class="form-label" for="form2Example28">کلمه عبور</label>
                <input type="password" id="form2Example28" class="form-control form-control-lg"
                       v-model="login.password" v-on:keyup="passKeyUp"/>
              </div>

              <div class="pt-1 mb-4">
                <button class="btn btn-success btn-lg d-flex justify-content-between align-items-center login-btn"
                        :class="{'w-100': loading}"
                        v-on:click="loginSubmit" :disabled="loading">
                  <i class="fa fa-spinner fa-spin mx-1" v-if="loading"></i>
                  <span class="mx-1">ورود</span>
                </button>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 px-0 d-none d-sm-block">
          <svg class="animated w-100" id="freepik_stories-trip" viewBox="0 0 500 500" version="1.1">
            <g id="freepik--background-simple--inject-11" class="animable"
               style="transform-origin: 249.659px 238.051px;">
              <path
                  d="M425.6,320.52a183.58,183.58,0,0,0,.74-38.44c-9-112-98.17-230.55-198.61-203.07C193,88.5,167.31,114.43,152,151.68,140.76,179,132.79,211,114.51,232.85c-30,35.9-66.16,92.06-20.67,141.1s101.31,17.2,148.86,14.67c40-2.13,80.37,13.52,120.22,7.89C400.77,391.16,420.45,360,425.6,320.52Z"
                  style="fill: #FFC100; transform-origin: 249.659px 238.051px;" id="el34nxemph7ek"
                  class="animable"></path>
              <g id="ele3o0og02hg">
                <path
                    d="M425.6,320.52a183.58,183.58,0,0,0,.74-38.44c-9-112-98.17-230.55-198.61-203.07C193,88.5,167.31,114.43,152,151.68,140.76,179,132.79,211,114.51,232.85c-30,35.9-66.16,92.06-20.67,141.1s101.31,17.2,148.86,14.67c40-2.13,80.37,13.52,120.22,7.89C400.77,391.16,420.45,360,425.6,320.52Z"
                    style="fill: rgb(255, 255, 255); opacity: 0.8; transform-origin: 249.659px 238.051px;"
                    class="animable" id="elf7jcyddgo7"></path>
              </g>
            </g>
            <g id="freepik--Clouds--inject-11" class="animable animator-active"
               style="transform-origin: 262.471px 170.798px;">
              <path
                  d="M414.44,160.51c-4.46-2.43-6.49-.41-8.11-2.43s4.46-7.3-7.7-12.57c0,0-.81-11.35-17.43-11.76S369,145.1,364.57,147.94s-5.67-1.62-10.13,1.22-2.43,8.51-6.08,9.32-8.52-3.65-13-.81-4.45,5.27-6.48,5.27-6.08-1.62-8.52,0-5.27,3.65-5.27,3.65H417.68S418.9,162.94,414.44,160.51Z"
                  style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 366.461px 150.165px;"
                  id="elhi61jn27m6m" class="animable"></path>
              <path
                  d="M157.28,220.52c-2.25-1.23-3.28-.21-4.1-1.23s2.26-3.69-3.89-6.35c0,0-.41-5.73-8.8-5.93s-6.14,5.73-8.4,7.16-2.86-.82-5.11.62-1.23,4.3-3.08,4.71-4.3-1.85-6.55-.41-2.25,2.66-3.27,2.66-3.08-.82-4.3,0-2.67,1.84-2.67,1.84h51.81S159.53,221.75,157.28,220.52Z"
                  style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 133.053px 215.298px;"
                  id="elvzzmw59xq" class="animable"></path>
              <path
                  d="M251.28,131.52c-2.25-1.23-3.28-.21-4.1-1.23s2.26-3.69-3.89-6.35c0,0-.41-5.73-8.8-5.93s-6.14,5.73-8.4,7.16-2.86-.82-5.11.62-1.23,4.3-3.08,4.71-4.3-1.85-6.55-.41-2.25,2.66-3.27,2.66-3.08-.82-4.3,0-2.67,1.84-2.67,1.84h51.81S253.53,132.75,251.28,131.52Z"
                  style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 227.053px 126.298px;"
                  id="el6cq59wz2vsd" class="animable"></path>
            </g>
            <g id="freepik--Trees--inject-11" class="animable" style="transform-origin: 253.5px 307.571px;">
              <path
                  d="M385.77,402.67H434c-.92-5.89-4.71-4.85-5.21-14-.25-4.6,4-10.29,3.64-16.33-.31-5-5.22-10.08-5.6-15.78-.34-5.14,3.85-10.84,3.44-16.38-.38-5.23-5.36-10.26-5.8-15.7s3.67-11.07,3.19-16.43-5.55-10.31-6.08-15.6,3.41-11.29,2.81-16.5c-.65-5.52-5.86-10.3-6.57-15.39-.79-5.67,2.91-11.72,2-16.61-1.06-6-6.64-10.34-7.81-14.76-2.19-8.24-1.92-16.19-4.5-16.7-2.76-.56-3.39,7.23-5.48,15.93-1,4.38-6.51,8.81-7.4,14.81-.73,4.86,3.13,10.76,2.5,16.41-.57,5.05-5.65,9.91-6.14,15.41-.47,5.17,3.66,10.87,3.25,16.27s-5.33,10.27-5.67,15.6,3.91,10.93,3.62,16.19-5.13,10.5-5.38,15.7c-.26,5.49,4.07,11,3.86,16.13-.23,5.65-5,10.83-5.18,15.77-.22,6,4.18,11.52,4.05,16.08-.3,9.91-4.83,7.86-5,15.83Z"
                  style="fill: #FFC100; transform-origin: 409.27px 307.566px;" id="el64ebqoazu0k"
                  class="animable"></path>
              <g id="elgkj9gncf8sj">
                <path
                    d="M385.77,402.67H434c-.92-5.89-4.71-4.85-5.21-14-.25-4.6,4-10.29,3.64-16.33-.31-5-5.22-10.08-5.6-15.78-.34-5.14,3.85-10.84,3.44-16.38-.38-5.23-5.36-10.26-5.8-15.7s3.67-11.07,3.19-16.43-5.55-10.31-6.08-15.6,3.41-11.29,2.81-16.5c-.65-5.52-5.86-10.3-6.57-15.39-.79-5.67,2.91-11.72,2-16.61-1.06-6-6.64-10.34-7.81-14.76-2.19-8.24-1.92-16.19-4.5-16.7-2.76-.56-3.39,7.23-5.48,15.93-1,4.38-6.51,8.81-7.4,14.81-.73,4.86,3.13,10.76,2.5,16.41-.57,5.05-5.65,9.91-6.14,15.41-.47,5.17,3.66,10.87,3.25,16.27s-5.33,10.27-5.67,15.6,3.91,10.93,3.62,16.19-5.13,10.5-5.38,15.7c-.26,5.49,4.07,11,3.86,16.13-.23,5.65-5,10.83-5.18,15.77-.22,6,4.18,11.52,4.05,16.08-.3,9.91-4.83,7.86-5,15.83Z"
                    style="fill: rgb(255, 255, 255); opacity: 0.5; transform-origin: 409.27px 307.566px;"
                    class="animable" id="elszn799txd2g"></path>
              </g>
              <line x1="406.46" y1="228.34" x2="406.46" y2="400.45"
                    style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 406.46px 314.395px;"
                    id="el9k90md76k7r" class="animable"></line>
              <polyline points="413.98 246.38 406.14 253.15 399.72 244.59"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 406.85px 248.87px;"
                        id="elwwi9lhpsgx" class="animable"></polyline>
              <polyline points="413.98 276.34 406.14 283.11 399.72 274.55"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 406.85px 278.83px;"
                        id="elgymgqe7y0sa" class="animable"></polyline>
              <polyline points="413.98 304.51 406.14 311.29 399.72 302.73"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 406.85px 307.01px;"
                        id="el0pjvnzl2v0q" class="animable"></polyline>
              <polyline points="413.98 338.04 406.14 344.81 399.72 336.25"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 406.85px 340.53px;"
                        id="eleiq2auoxxz" class="animable"></polyline>
              <polyline points="413.98 371.92 406.14 378.69 399.72 370.13"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 406.85px 374.41px;"
                        id="el5cochrwnuge" class="animable"></polyline>
              <path
                  d="M61,402.67h48.2c-.93-5.89-4.71-4.85-5.22-14-.25-4.6,4-10.29,3.64-16.33-.3-5-5.21-10.08-5.59-15.78-.35-5.14,3.84-10.84,3.44-16.38-.39-5.23-5.36-10.26-5.8-15.7s3.67-11.07,3.19-16.43-5.55-10.31-6.09-15.6,3.42-11.29,2.81-16.5c-.64-5.52-5.86-10.3-6.56-15.39-.79-5.67,2.9-11.72,2-16.61-1.06-6-6.64-10.34-7.82-14.76C85.09,221,85.36,213,82.78,212.5c-2.76-.56-3.39,7.23-5.48,15.93-1,4.38-6.51,8.81-7.41,14.81-.72,4.86,3.14,10.76,2.5,16.41-.56,5.05-5.64,9.91-6.14,15.41-.46,5.17,3.66,10.87,3.26,16.27s-5.33,10.27-5.67,15.6,3.91,10.93,3.62,16.19-5.14,10.5-5.39,15.7c-.26,5.49,4.08,11,3.87,16.13-.24,5.65-5,10.83-5.19,15.77-.21,6,4.19,11.52,4,16.08-.29,9.91-4.83,7.86-5,15.83Z"
                  style="fill: #FFC100; transform-origin: 84.475px 307.571px;" id="elmgal2wbscmj"
                  class="animable"></path>
              <g id="elcknh12tovc7">
                <path
                    d="M61,402.67h48.2c-.93-5.89-4.71-4.85-5.22-14-.25-4.6,4-10.29,3.64-16.33-.3-5-5.21-10.08-5.59-15.78-.35-5.14,3.84-10.84,3.44-16.38-.39-5.23-5.36-10.26-5.8-15.7s3.67-11.07,3.19-16.43-5.55-10.31-6.09-15.6,3.42-11.29,2.81-16.5c-.64-5.52-5.86-10.3-6.56-15.39-.79-5.67,2.9-11.72,2-16.61-1.06-6-6.64-10.34-7.82-14.76C85.09,221,85.36,213,82.78,212.5c-2.76-.56-3.39,7.23-5.48,15.93-1,4.38-6.51,8.81-7.41,14.81-.72,4.86,3.14,10.76,2.5,16.41-.56,5.05-5.64,9.91-6.14,15.41-.46,5.17,3.66,10.87,3.26,16.27s-5.33,10.27-5.67,15.6,3.91,10.93,3.62,16.19-5.14,10.5-5.39,15.7c-.26,5.49,4.08,11,3.87,16.13-.24,5.65-5,10.83-5.19,15.77-.21,6,4.19,11.52,4,16.08-.29,9.91-4.83,7.86-5,15.83Z"
                    style="fill: rgb(255, 255, 255); opacity: 0.5; transform-origin: 84.475px 307.571px;"
                    class="animable" id="elh73t4t1tv7r"></path>
              </g>
              <line x1="81.72" y1="228.34" x2="81.72" y2="400.45"
                    style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 81.72px 314.395px;"
                    id="elb2eausbwzd4" class="animable"></line>
              <polyline points="89.25 246.38 81.4 253.15 74.98 244.59"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 82.115px 248.87px;"
                        id="elqlvt3khl8l" class="animable"></polyline>
              <polyline points="89.25 276.34 81.4 283.11 74.98 274.55"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 82.115px 278.83px;"
                        id="elj6h9e1q84dk" class="animable"></polyline>
              <polyline points="89.25 304.51 81.4 311.29 74.98 302.73"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 82.115px 307.01px;"
                        id="elmcdwq86pugq" class="animable"></polyline>
              <polyline points="89.25 338.04 81.4 344.81 74.98 336.25"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 82.115px 340.53px;"
                        id="el2enbglz4g0w" class="animable"></polyline>
              <polyline points="89.25 371.92 81.4 378.69 74.98 370.13"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 82.115px 374.41px;"
                        id="el3m5ar9ew9vy" class="animable"></polyline>
              <path
                  d="M314.71,402.67h36c-.69-4.4-3.52-3.62-3.89-10.45-.19-3.43,3-7.68,2.71-12.2-.22-3.72-3.89-7.53-4.17-11.78-.26-3.84,2.87-8.1,2.56-12.23-.28-3.92-4-7.67-4.33-11.73S346.33,336,346,332s-4.15-7.69-4.55-11.64,2.55-8.44,2.1-12.33c-.48-4.13-4.38-7.69-4.9-11.49-.59-4.24,2.17-8.76,1.52-12.41-.79-4.48-5-7.72-5.84-11C332.67,267,332.87,261,331,260.63s-2.53,5.4-4.1,11.9c-.78,3.27-4.86,6.58-5.53,11.06-.54,3.63,2.34,8,1.87,12.26-.42,3.77-4.22,7.4-4.59,11.51-.35,3.86,2.74,8.12,2.43,12.15s-4,7.67-4.23,11.65,2.92,8.16,2.71,12.1-3.84,7.84-4,11.72c-.19,4.1,3,8.24,2.89,12-.18,4.22-3.74,8.09-3.88,11.77-.15,4.48,3.13,8.61,3,12-.22,7.4-3.61,5.87-3.73,11.82Z"
                  style="fill: #FFC100; transform-origin: 332.275px 331.642px;" id="elgfv1n0amwx7"
                  class="animable"></path>
              <g id="ely6lnj1bktji">
                <path
                    d="M314.71,402.67h36c-.69-4.4-3.52-3.62-3.89-10.45-.19-3.43,3-7.68,2.71-12.2-.22-3.72-3.89-7.53-4.17-11.78-.26-3.84,2.87-8.1,2.56-12.23-.28-3.92-4-7.67-4.33-11.73S346.33,336,346,332s-4.15-7.69-4.55-11.64,2.55-8.44,2.1-12.33c-.48-4.13-4.38-7.69-4.9-11.49-.59-4.24,2.17-8.76,1.52-12.41-.79-4.48-5-7.72-5.84-11C332.67,267,332.87,261,331,260.63s-2.53,5.4-4.1,11.9c-.78,3.27-4.86,6.58-5.53,11.06-.54,3.63,2.34,8,1.87,12.26-.42,3.77-4.22,7.4-4.59,11.51-.35,3.86,2.74,8.12,2.43,12.15s-4,7.67-4.23,11.65,2.92,8.16,2.71,12.1-3.84,7.84-4,11.72c-.19,4.1,3,8.24,2.89,12-.18,4.22-3.74,8.09-3.88,11.77-.15,4.48,3.13,8.61,3,12-.22,7.4-3.61,5.87-3.73,11.82Z"
                    style="fill: rgb(255, 255, 255); opacity: 0.5; transform-origin: 332.275px 331.642px;"
                    class="animable" id="el2nhy4fmt2rr"></path>
              </g>
              <line x1="330.16" y1="272.46" x2="330.16" y2="401.01"
                    style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 330.16px 336.735px;"
                    id="eld5s2b2qusl7" class="animable"></line>
              <polyline points="335.78 285.94 329.92 291 325.12 284.6"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 330.45px 287.8px;"
                        id="elvob3he9no1f" class="animable"></polyline>
              <polyline points="335.78 308.31 329.92 313.37 325.12 306.98"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 330.45px 310.175px;"
                        id="elh5g1w4k2dgf" class="animable"></polyline>
              <polyline points="335.78 329.36 329.92 334.42 325.12 328.02"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 330.45px 331.22px;"
                        id="el0dkydgmc55ts" class="animable"></polyline>
              <polyline points="335.78 354.39 329.92 359.46 325.12 353.06"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 330.45px 356.26px;"
                        id="elxuw9sysuu9n" class="animable"></polyline>
              <polyline points="335.78 379.7 329.92 384.76 325.12 378.37"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 330.45px 381.565px;"
                        id="ellvne7o06zu" class="animable"></polyline>
              <path
                  d="M429.71,402.67h36c-.69-4.4-3.52-3.62-3.89-10.45-.19-3.43,3-7.68,2.71-12.2-.22-3.72-3.89-7.53-4.17-11.78-.26-3.84,2.87-8.1,2.56-12.23-.28-3.92-4-7.67-4.33-11.73S461.33,336,461,332s-4.15-7.69-4.55-11.64,2.55-8.44,2.1-12.33c-.48-4.13-4.38-7.69-4.9-11.49-.59-4.24,2.17-8.76,1.52-12.41-.79-4.48-5-7.72-5.84-11C447.67,267,447.87,261,446,260.63s-2.53,5.4-4.1,11.9c-.78,3.27-4.86,6.58-5.53,11.06-.54,3.63,2.34,8,1.87,12.26-.42,3.77-4.22,7.4-4.59,11.51-.35,3.86,2.74,8.12,2.43,12.15s-4,7.67-4.23,11.65,2.92,8.16,2.71,12.1-3.84,7.84-4,11.72c-.19,4.1,3,8.24,2.89,12-.18,4.22-3.74,8.09-3.88,11.77-.15,4.48,3.13,8.61,3,12-.22,7.4-3.61,5.87-3.73,11.82Z"
                  style="fill: #FFC100; transform-origin: 447.275px 331.642px;" id="el7mem6hakevs"
                  class="animable"></path>
              <g id="elttdradjt2vl">
                <path
                    d="M429.71,402.67h36c-.69-4.4-3.52-3.62-3.89-10.45-.19-3.43,3-7.68,2.71-12.2-.22-3.72-3.89-7.53-4.17-11.78-.26-3.84,2.87-8.1,2.56-12.23-.28-3.92-4-7.67-4.33-11.73S461.33,336,461,332s-4.15-7.69-4.55-11.64,2.55-8.44,2.1-12.33c-.48-4.13-4.38-7.69-4.9-11.49-.59-4.24,2.17-8.76,1.52-12.41-.79-4.48-5-7.72-5.84-11C447.67,267,447.87,261,446,260.63s-2.53,5.4-4.1,11.9c-.78,3.27-4.86,6.58-5.53,11.06-.54,3.63,2.34,8,1.87,12.26-.42,3.77-4.22,7.4-4.59,11.51-.35,3.86,2.74,8.12,2.43,12.15s-4,7.67-4.23,11.65,2.92,8.16,2.71,12.1-3.84,7.84-4,11.72c-.19,4.1,3,8.24,2.89,12-.18,4.22-3.74,8.09-3.88,11.77-.15,4.48,3.13,8.61,3,12-.22,7.4-3.61,5.87-3.73,11.82Z"
                    style="fill: rgb(255, 255, 255); opacity: 0.5; transform-origin: 447.275px 331.642px;"
                    class="animable" id="elv74zgqp3i4"></path>
              </g>
              <line x1="445.16" y1="272.46" x2="445.16" y2="401.01"
                    style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 445.16px 336.735px;"
                    id="elctq3gldi2ui" class="animable"></line>
              <polyline points="450.78 285.94 444.92 291 440.12 284.6"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 445.45px 287.8px;"
                        id="el6mfrnn4srj2" class="animable"></polyline>
              <polyline points="450.78 308.31 444.92 313.37 440.12 306.98"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 445.45px 310.175px;"
                        id="el0uccy5ajoivp" class="animable"></polyline>
              <polyline points="450.78 329.36 444.92 334.42 440.12 328.02"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 445.45px 331.22px;"
                        id="el5jrloifekzt" class="animable"></polyline>
              <polyline points="450.78 354.39 444.92 359.46 440.12 353.06"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 445.45px 356.26px;"
                        id="el046mjjgi50f" class="animable"></polyline>
              <polyline points="450.78 379.7 444.92 384.76 440.12 378.37"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 445.45px 381.565px;"
                        id="elxumlo5iryoo" class="animable"></polyline>
              <path
                  d="M275,402.67h36c-.7-4.4-3.52-3.62-3.9-10.45-.19-3.43,3-7.68,2.72-12.2-.23-3.72-3.89-7.53-4.18-11.78-.26-3.84,2.87-8.1,2.57-12.23-.29-3.92-4-7.67-4.33-11.73s2.74-8.27,2.38-12.28-4.14-7.69-4.55-11.64,2.56-8.44,2.1-12.33c-.48-4.13-4.37-7.69-4.9-11.49-.59-4.24,2.17-8.76,1.52-12.41-.79-4.48-4.95-7.72-5.83-11C293,267,293.19,261,291.26,260.63s-2.53,5.4-4.09,11.9c-.79,3.27-4.86,6.58-5.53,11.06-.55,3.63,2.34,8,1.86,12.26-.42,3.77-4.21,7.4-4.58,11.51-.35,3.86,2.73,8.12,2.43,12.15s-4,7.67-4.24,11.65,2.93,8.16,2.71,12.1-3.84,7.84-4,11.72c-.2,4.1,3,8.24,2.88,12-.17,4.22-3.74,8.09-3.87,11.77-.16,4.48,3.13,8.61,3,12-.22,7.4-3.6,5.87-3.72,11.82Z"
                  style="fill: #FFC100; transform-origin: 292.555px 331.642px;" id="elrzkmuapilk"
                  class="animable"></path>
              <g id="eldttz5vmfyt">
                <path
                    d="M275,402.67h36c-.7-4.4-3.52-3.62-3.9-10.45-.19-3.43,3-7.68,2.72-12.2-.23-3.72-3.89-7.53-4.18-11.78-.26-3.84,2.87-8.1,2.57-12.23-.29-3.92-4-7.67-4.33-11.73s2.74-8.27,2.38-12.28-4.14-7.69-4.55-11.64,2.56-8.44,2.1-12.33c-.48-4.13-4.37-7.69-4.9-11.49-.59-4.24,2.17-8.76,1.52-12.41-.79-4.48-4.95-7.72-5.83-11C293,267,293.19,261,291.26,260.63s-2.53,5.4-4.09,11.9c-.79,3.27-4.86,6.58-5.53,11.06-.55,3.63,2.34,8,1.86,12.26-.42,3.77-4.21,7.4-4.58,11.51-.35,3.86,2.73,8.12,2.43,12.15s-4,7.67-4.24,11.65,2.93,8.16,2.71,12.1-3.84,7.84-4,11.72c-.2,4.1,3,8.24,2.88,12-.17,4.22-3.74,8.09-3.87,11.77-.16,4.48,3.13,8.61,3,12-.22,7.4-3.6,5.87-3.72,11.82Z"
                    style="fill: rgb(255, 255, 255); opacity: 0.5; transform-origin: 292.555px 331.642px;"
                    class="animable" id="elc5ua4hnzcum"></path>
              </g>
              <line x1="290.47" y1="272.46" x2="290.47" y2="401.01"
                    style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 290.47px 336.735px;"
                    id="el26p6yyqlcfq" class="animable"></line>
              <polyline points="296.09 285.94 290.23 291 285.44 284.6"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 290.765px 287.8px;"
                        id="elonf2ptj08q" class="animable"></polyline>
              <polyline points="296.09 308.31 290.23 313.37 285.44 306.98"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 290.765px 310.175px;"
                        id="el7owqvtxvfq" class="animable"></polyline>
              <polyline points="296.09 329.36 290.23 334.42 285.44 328.02"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 290.765px 331.22px;"
                        id="elz7r3dykmhme" class="animable"></polyline>
              <polyline points="296.09 354.39 290.23 359.46 285.44 353.06"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 290.765px 356.26px;"
                        id="elud61jabx5d" class="animable"></polyline>
              <polyline points="296.09 379.7 290.23 384.76 285.44 378.37"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 290.765px 381.565px;"
                        id="el7z84v2dg1t" class="animable"></polyline>
              <path
                  d="M205.1,402.67h36c-.69-4.4-3.52-3.62-3.89-10.45-.19-3.43,3-7.68,2.71-12.2-.22-3.72-3.89-7.53-4.17-11.78-.26-3.84,2.87-8.1,2.57-12.23-.29-3.92-4-7.67-4.34-11.73s2.75-8.27,2.39-12.28-4.15-7.69-4.55-11.64,2.55-8.44,2.1-12.33c-.48-4.13-4.38-7.69-4.9-11.49-.59-4.24,2.17-8.76,1.52-12.41-.79-4.48-5-7.72-5.84-11-1.63-6.15-1.43-12.09-3.35-12.47-2.07-.41-2.53,5.4-4.1,11.9-.78,3.27-4.86,6.58-5.53,11.06-.54,3.63,2.34,8,1.87,12.26-.42,3.77-4.22,7.4-4.59,11.51-.35,3.86,2.74,8.12,2.43,12.15s-4,7.67-4.23,11.65,2.92,8.16,2.71,12.1-3.84,7.84-4,11.72c-.19,4.1,3,8.24,2.89,12-.18,4.22-3.74,8.09-3.88,11.77-.15,4.48,3.13,8.61,3,12-.22,7.4-3.61,5.87-3.73,11.82Z"
                  style="fill: #FFC100; transform-origin: 222.645px 331.655px;" id="el7ils4dfdnz"
                  class="animable"></path>
              <g id="elwr72fz4mktl">
                <path
                    d="M205.1,402.67h36c-.69-4.4-3.52-3.62-3.89-10.45-.19-3.43,3-7.68,2.71-12.2-.22-3.72-3.89-7.53-4.17-11.78-.26-3.84,2.87-8.1,2.57-12.23-.29-3.92-4-7.67-4.34-11.73s2.75-8.27,2.39-12.28-4.15-7.69-4.55-11.64,2.55-8.44,2.1-12.33c-.48-4.13-4.38-7.69-4.9-11.49-.59-4.24,2.17-8.76,1.52-12.41-.79-4.48-5-7.72-5.84-11-1.63-6.15-1.43-12.09-3.35-12.47-2.07-.41-2.53,5.4-4.1,11.9-.78,3.27-4.86,6.58-5.53,11.06-.54,3.63,2.34,8,1.87,12.26-.42,3.77-4.22,7.4-4.59,11.51-.35,3.86,2.74,8.12,2.43,12.15s-4,7.67-4.23,11.65,2.92,8.16,2.71,12.1-3.84,7.84-4,11.72c-.19,4.1,3,8.24,2.89,12-.18,4.22-3.74,8.09-3.88,11.77-.15,4.48,3.13,8.61,3,12-.22,7.4-3.61,5.87-3.73,11.82Z"
                    style="fill: rgb(255, 255, 255); opacity: 0.5; transform-origin: 222.645px 331.655px;"
                    class="animable" id="elgmwp1f7g26o"></path>
              </g>
              <line x1="220.55" y1="272.46" x2="220.55" y2="401.01"
                    style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 220.55px 336.735px;"
                    id="el2vh4esoiobf" class="animable"></line>
              <polyline points="226.17 285.94 220.31 291 215.51 284.6"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 220.84px 287.8px;"
                        id="eludg3ctzd6ed" class="animable"></polyline>
              <polyline points="226.17 308.31 220.31 313.37 215.51 306.98"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 220.84px 310.175px;"
                        id="elku934tf9am" class="animable"></polyline>
              <polyline points="226.17 329.36 220.31 334.42 215.51 328.02"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 220.84px 331.22px;"
                        id="elt9pbcd3wu3h" class="animable"></polyline>
              <polyline points="226.17 354.39 220.31 359.46 215.51 353.06"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 220.84px 356.26px;"
                        id="elnzguqq3g4nb" class="animable"></polyline>
              <polyline points="226.17 379.7 220.31 384.76 215.51 378.37"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 220.84px 381.565px;"
                        id="el2ew4wb4vqvq" class="animable"></polyline>
              <path
                  d="M117.13,391.34h30.22c-.58-3.7-2.95-3-3.27-8.78-.16-2.88,2.51-6.45,2.28-10.24-.19-3.12-3.27-6.32-3.51-9.89-.21-3.23,2.42-6.8,2.16-10.27-.24-3.29-3.36-6.44-3.64-9.85s2.31-6.94,2-10.3-3.47-6.46-3.81-9.78,2.14-7.08,1.76-10.35c-.4-3.46-3.67-6.46-4.12-9.65-.49-3.55,1.83-7.35,1.28-10.42-.66-3.76-4.16-6.48-4.9-9.25-1.37-5.17-1.2-10.15-2.82-10.47s-2.12,4.53-3.43,10c-.66,2.74-4.08,5.52-4.64,9.28-.46,3.05,2,6.75,1.56,10.29-.35,3.17-3.54,6.22-3.85,9.67-.29,3.24,2.3,6.81,2,10.2s-3.34,6.43-3.55,9.78,2.45,6.85,2.27,10.15-3.22,6.59-3.38,9.85c-.16,3.44,2.56,6.92,2.42,10.11-.14,3.54-3.14,6.79-3.25,9.89-.13,3.75,2.63,7.22,2.54,10.08-.18,6.22-3,4.93-3.13,9.93Z"
                  style="fill: #FFC100; transform-origin: 131.835px 331.708px;" id="elaym8tedwdw6"
                  class="animable"></path>
              <g id="elllmkfloh9d">
                <path
                    d="M117.13,391.34h30.22c-.58-3.7-2.95-3-3.27-8.78-.16-2.88,2.51-6.45,2.28-10.24-.19-3.12-3.27-6.32-3.51-9.89-.21-3.23,2.42-6.8,2.16-10.27-.24-3.29-3.36-6.44-3.64-9.85s2.31-6.94,2-10.3-3.47-6.46-3.81-9.78,2.14-7.08,1.76-10.35c-.4-3.46-3.67-6.46-4.12-9.65-.49-3.55,1.83-7.35,1.28-10.42-.66-3.76-4.16-6.48-4.9-9.25-1.37-5.17-1.2-10.15-2.82-10.47s-2.12,4.53-3.43,10c-.66,2.74-4.08,5.52-4.64,9.28-.46,3.05,2,6.75,1.56,10.29-.35,3.17-3.54,6.22-3.85,9.67-.29,3.24,2.3,6.81,2,10.2s-3.34,6.43-3.55,9.78,2.45,6.85,2.27,10.15-3.22,6.59-3.38,9.85c-.16,3.44,2.56,6.92,2.42,10.11-.14,3.54-3.14,6.79-3.25,9.89-.13,3.75,2.63,7.22,2.54,10.08-.18,6.22-3,4.93-3.13,9.93Z"
                    style="fill: rgb(255, 255, 255); opacity: 0.5; transform-origin: 131.835px 331.708px;"
                    class="animable" id="elvgq7jgcn1uc"></path>
              </g>
              <line x1="130.1" y1="282.02" x2="130.1" y2="389.94"
                    style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 130.1px 335.98px;"
                    id="elrwft14e6ng" class="animable"></line>
              <polyline points="134.82 293.33 129.9 297.58 125.88 292.21"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 130.35px 294.895px;"
                        id="elwvuc75qq3i" class="animable"></polyline>
              <polyline points="134.82 312.12 129.9 316.37 125.88 311"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 130.35px 313.685px;"
                        id="eliqqstrf75wi" class="animable"></polyline>
              <polyline points="134.82 329.78 129.9 334.03 125.88 328.67"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 130.35px 331.35px;"
                        id="elps1aiahdyfn" class="animable"></polyline>
              <polyline points="134.82 350.81 129.9 355.05 125.88 349.69"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 130.35px 352.37px;"
                        id="ellpg2ldpvro" class="animable"></polyline>
              <polyline points="134.82 372.05 129.9 376.3 125.88 370.93"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 130.35px 373.615px;"
                        id="elzzirgqi1bve" class="animable"></polyline>
              <path
                  d="M162.91,402.67h44.16c-.85-5.4-4.32-4.45-4.78-12.82-.23-4.21,3.67-9.43,3.34-15-.28-4.57-4.78-9.24-5.13-14.46-.31-4.71,3.52-9.93,3.15-15-.35-4.8-4.91-9.4-5.31-14.39s3.36-10.14,2.92-15.06-5.08-9.43-5.58-14.28,3.14-10.35,2.58-15.12c-.59-5.07-5.37-9.44-6-14.1-.72-5.2,2.67-10.75,1.87-15.23-1-5.49-6.08-9.47-7.16-13.52-2-7.55-1.75-14.83-4.12-15.31-2.52-.5-3.1,6.63-5,14.61-1,4-6,8.06-6.78,13.56-.67,4.45,2.87,9.87,2.29,15-.52,4.63-5.18,9.08-5.63,14.12-.43,4.74,3.35,10,3,14.91s-4.88,9.41-5.19,14.29,3.59,10,3.32,14.84-4.71,9.62-4.94,14.38c-.24,5,3.74,10.12,3.54,14.79-.21,5.17-4.59,9.92-4.75,14.44-.19,5.49,3.84,10.56,3.71,14.74-.27,9.08-4.42,7.2-4.57,14.5Z"
                  style="fill: #FFC100; transform-origin: 184.46px 315.513px;" id="elndf0ocbqlz"
                  class="animable"></path>
              <g id="elgcd19etqyu">
                <path
                    d="M162.91,402.67h44.16c-.85-5.4-4.32-4.45-4.78-12.82-.23-4.21,3.67-9.43,3.34-15-.28-4.57-4.78-9.24-5.13-14.46-.31-4.71,3.52-9.93,3.15-15-.35-4.8-4.91-9.4-5.31-14.39s3.36-10.14,2.92-15.06-5.08-9.43-5.58-14.28,3.14-10.35,2.58-15.12c-.59-5.07-5.37-9.44-6-14.1-.72-5.2,2.67-10.75,1.87-15.23-1-5.49-6.08-9.47-7.16-13.52-2-7.55-1.75-14.83-4.12-15.31-2.52-.5-3.1,6.63-5,14.61-1,4-6,8.06-6.78,13.56-.67,4.45,2.87,9.87,2.29,15-.52,4.63-5.18,9.08-5.63,14.12-.43,4.74,3.35,10,3,14.91s-4.88,9.41-5.19,14.29,3.59,10,3.32,14.84-4.71,9.62-4.94,14.38c-.24,5,3.74,10.12,3.54,14.79-.21,5.17-4.59,9.92-4.75,14.44-.19,5.49,3.84,10.56,3.71,14.74-.27,9.08-4.42,7.2-4.57,14.5Z"
                    style="fill: rgb(255, 255, 255); opacity: 0.5; transform-origin: 184.46px 315.513px;"
                    class="animable" id="elzc9pdkrfqu"></path>
              </g>
              <line x1="181.87" y1="242.93" x2="181.87" y2="400.64"
                    style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 181.87px 321.785px;"
                    id="el35lvtfbd4uj" class="animable"></line>
              <polyline points="188.76 259.46 181.57 265.67 175.69 257.83"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 182.225px 261.75px;"
                        id="el4ks447uarw" class="animable"></polyline>
              <polyline points="188.76 286.91 181.57 293.12 175.69 285.28"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 182.225px 289.2px;"
                        id="elxshmj6b9wo" class="animable"></polyline>
              <polyline points="188.76 312.73 181.57 318.94 175.69 311.09"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 182.225px 315.015px;"
                        id="ele2twzns7rul" class="animable"></polyline>
              <polyline points="188.76 343.45 181.57 349.65 175.69 341.81"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 182.225px 345.73px;"
                        id="eltiok0976sxn" class="animable"></polyline>
              <polyline points="188.76 374.49 181.57 380.7 175.69 372.86"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 182.225px 376.78px;"
                        id="el5fl6t903nut" class="animable"></polyline>
              <polygon
                  points="469.94 390.05 462.44 387 454.93 390.05 447.43 387 439.92 390.05 432.42 387 424.92 390.05 417.41 387 409.91 390.05 402.4 387 394.9 390.05 387.4 387 379.89 390.05 372.39 387 364.89 390.05 357.38 387 349.88 390.05 342.37 387 334.87 390.05 327.37 387 319.86 390.05 312.36 387 304.85 390.05 297.35 387 289.85 390.05 282.34 387 274.84 390.05 267.34 387 259.83 390.05 252.33 387 244.83 390.05 237.32 387 229.82 390.05 222.32 387 214.82 390.05 207.31 387 199.81 390.05 192.31 387 184.81 390.05 177.31 387 169.8 390.05 162.3 387 154.8 390.05 147.3 387 139.8 390.05 132.3 387 124.8 390.05 117.29 387 109.79 390.05 102.29 387 94.79 390.05 87.29 387 79.79 390.05 72.29 387 64.79 390.05 57.29 387 49.79 390.05 42.29 387 36 389.56 36 402.68 471 402.68 471 389.62 469.94 390.05"
                  style="fill: #FFC100; transform-origin: 253.5px 394.84px;" id="elyrw1bmnikhs"
                  class="animable"></polygon>
            </g>
            <g id="freepik--Car--inject-11" class="animable" style="transform-origin: 253.335px 291.756px;">
              <path
                  d="M327,190.06a20.31,20.31,0,0,0-12.66,4.43,28.66,28.66,0,0,0-50.92-13,29.5,29.5,0,0,0-52.64,12.85,20,20,0,1,0,12.58,29.37,29.52,29.52,0,0,0,40.18-6.86,28.66,28.66,0,0,0,43.5,1.74,21.06,21.06,0,0,0,20,15.16c11.58,0,21-9.77,21-21.83S338.58,190.06,327,190.06Z"
                  style="fill: rgb(38, 50, 56); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 267.025px 201.758px;"
                  id="elu108jhq9cnj" class="animable"></path>
              <path
                  d="M223.36,225.18a1.48,1.48,0,0,1-1.37-.91L209.4,194.91a1.5,1.5,0,0,1,2.76-1.19l12.58,29.37a1.5,1.5,0,0,1-.78,2A1.61,1.61,0,0,1,223.36,225.18Z"
                  style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 217.076px 208.997px;"
                  id="el4bxfde7gear" class="animable"></path>
              <path d="M263.54,218.82a2,2,0,0,1-2-2l-.12-35.37a2,2,0,0,1,4,0l.12,35.36a2,2,0,0,1-2,2Z"
                    style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 263.48px 199.135px;"
                    id="el9105rz90nzg" class="animable"></path>
              <path
                  d="M307,220.56a2.39,2.39,0,0,1-.59-.08,2,2,0,0,1-1.33-2.5l7.3-24.07a2,2,0,0,1,3.83,1.16L309,219.14A2,2,0,0,1,307,220.56Z"
                  style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-miterlimit: 10; transform-origin: 310.644px 206.525px;"
                  id="el4uw758cuhh6" class="animable"></path>
              <path d="M316.24,202.26s23.57-9.73,29.72-9.73,2.57,2.05,0,4.61-3.84,5.38-2.56,8.2Z"
                    style="fill: #FFC100; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 332.799px 198.935px;"
                    id="elppf6oj02b7" class="animable"></path>
              <path
                  d="M176.08,209.7s60.21-13.33,178.85,0c0,0,2.05-.77.77-1.8s-51.76-10-99.16-9.48S177.36,203,176.08,209.7Z"
                  style="fill: #FFC100; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 266.1px 204.049px;"
                  id="elar83l4d4v19" class="animable"></path>
              <rect x="230.66" y="179.97" width="75.33" height="25.62" rx="4.36"
                    style="fill: #FFC100; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 268.325px 192.78px;"
                    id="elq4t1gfmbf6d" class="animable"></rect>
              <path d="M302.47,180H234.18a3.71,3.71,0,0,0-3.52,3.89v3.66H306v-3.66A3.71,3.71,0,0,0,302.47,180Z"
                    style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 268.33px 183.775px;"
                    id="elrhg9jw947sb" class="animable"></path>
              <rect x="221.69" y="204.57" width="93.27" height="28.7" rx="4.36"
                    style="fill: rgb(178, 178, 178); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 268.325px 218.92px;"
                    id="elpbmhwqrkm3e" class="animable"></rect>
              <path d="M310.6,204.57H226a4.36,4.36,0,0,0-4.35,4.36V213H315v-4.1A4.36,4.36,0,0,0,310.6,204.57Z"
                    style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 268.325px 208.785px;"
                    id="elhps79vldenu" class="animable"></path>
              <path d="M255.26,215.84h3.84v1.54a6.66,6.66,0,0,0,6.66,6.66h5.9a6.66,6.66,0,0,0,6.66-6.66v-1.79h3.58"
                    style="fill: none; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; stroke-width: 3px; transform-origin: 268.58px 219.815px;"
                    id="elu8pitjy10yl" class="animable"></path>
              <path
                  d="M316,232H219.51a17.29,17.29,0,0,0-11.41,4.29h0a17.31,17.31,0,0,0-4.65,6.53l-21.76,53.69a11.73,11.73,0,0,1-8.51,7.09l-25.48,5.22A31.32,31.32,0,0,0,134.46,315h0a31.3,31.3,0,0,0-11.23,18.8l-3.11,17a13.15,13.15,0,0,0,2.95,10.9h0a13.13,13.13,0,0,0,10,4.58h29.29l23,14h113l62.34-9,13.64-1a9.55,9.55,0,0,0,7.73-4.92,25.66,25.66,0,0,0,3.29-11.09c.34-8.66-2-17.33-6.33-25.66s-10.67-9.34-19-37S348,251.33,339.67,242,316,232,316,232Z"
                  style="fill: #FFC100; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 252.651px 306.14px;"
                  id="elwbmlyx6068q" class="animable"></path>
              <path
                  d="M186.67,312.67v56A7.33,7.33,0,0,0,194,376h88a9.67,9.67,0,0,0,7.23-3.25h0a9.66,9.66,0,0,0,2.45-6.43v-51"
                  style="fill: none; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 239.175px 344.335px;"
                  id="el32dmknvjqa2" class="animable"></path>
              <line x1="149.5" y1="320.5" x2="360.5" y2="320.5"
                    style="fill: rgb(38, 50, 56); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 255px 320.5px;"
                    id="elndml3iyozmq" class="animable"></line>
              <path
                  d="M287.33,324.67H276.67a2,2,0,0,1-2-2h0a2,2,0,0,1,2-2h10.66a2,2,0,0,1,2,2h0A2,2,0,0,1,287.33,324.67Z"
                  style="fill: rgb(38, 50, 56); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 282px 322.67px;"
                  id="eltnxni8b8vn" class="animable"></path>
              <path
                  d="M232,237h-3.2a25.87,25.87,0,0,0-24.31,17.05l-18.72,51.72a3.66,3.66,0,0,0,3.44,4.9H284a6.33,6.33,0,0,0,6.33-6.34V245.17a8.16,8.16,0,0,0-8.16-8.17Z"
                  style="fill: rgb(117, 117, 117); transform-origin: 237.942px 273.835px;" id="elqw52x2nzm4g"
                  class="animable"></path>
              <g style="clip-path: url(&quot;#freepik--clip-path--inject-11&quot;); transform-origin: 252.185px 273.659px;"
                 id="elxm2lar74h0f" class="animable">
                <path
                    d="M281,275.8s9.68,7.83,12.21,13.59,6,22.11,6,22.11H240.49s15.66-18,22.11-23.72S281,275.8,281,275.8Z"
                    style="fill: rgb(255, 255, 255); transform-origin: 269.85px 293.65px;" id="elu522yqhqpua"
                    class="animable"></path>
                <g style="clip-path: url(&quot;#freepik--clip-path-2--inject-11&quot;); transform-origin: 273.671px 294.335px;"
                   id="eltx082r3yye" class="animable">
                  <path
                      d="M276.78,291.52c1.25-1.25,3.74-.75,3.74,3.24a4.27,4.27,0,0,1-3.49,4.5,13.77,13.77,0,0,1,4.24.75c2,.75,1.25,5-3,6s-4.75-5.25-4.75-5.25a14.51,14.51,0,0,0-1.5,2.75c-.75,1.75-7.75,3-7.25-1.25s6.5-3.75,5.5-4.25-7.25-6.24-2-8,5.5,7,5.5,7S275.53,292.77,276.78,291.52Zm14.74-5s-.25-8.75-5.5-7,1,7.5,2,8-5,0-5.5,4.25,6.5,3,7.25,1.25a14.51,14.51,0,0,1,1.5-2.75s.5,6.24,4.75,5.24,5-5.24,3-6a13.82,13.82,0,0,0-4.24-.75,4.27,4.27,0,0,0,3.49-4.5c0-4-2.49-4.5-3.74-3.25S291.52,286.52,291.52,286.52Zm.5,21s-.25-8.75-5.5-7,1,7.5,2,8-5,0-5.5,4.24,6.5,3,7.25,1.25a14.19,14.19,0,0,1,1.5-2.74s.5,6.24,4.75,5.24,5-5.24,3-6a13.82,13.82,0,0,0-4.24-.75,4.27,4.27,0,0,0,3.49-4.5c0-4-2.49-4.5-3.74-3.25S292,307.51,292,307.51Zm-36.23.5s-.25-8.75-5.5-7,1,7.5,2,8-5,0-5.5,4.24,6.5,3,7.25,1.25a14.19,14.19,0,0,1,1.5-2.74s.5,6.24,4.75,5.24,5-5.24,3-6a13.77,13.77,0,0,0-4.24-.75,4.27,4.27,0,0,0,3.49-4.5c0-4-2.49-4.5-3.74-3.25S255.79,308,255.79,308Zm18-29.24s-.25-8.74-5.5-7,1,7.49,2,8-5,0-5.5,4.25,6.5,3,7.25,1.25a14.51,14.51,0,0,1,1.5-2.75s.5,6.25,4.75,5.25,5-5.25,3-6A13.77,13.77,0,0,0,277,281a4.27,4.27,0,0,0,3.49-4.49c0-4-2.49-4.5-3.74-3.25S273.78,278.77,273.78,278.77Z"
                      style="fill: #FFC100; transform-origin: 273.671px 294.335px;" id="ele2ad4w0po0p"
                      class="animable"></path>
                </g>
                <path
                    d="M281,275.8s9.68,7.83,12.21,13.59,6,22.11,6,22.11H240.49s15.66-18,22.11-23.72S281,275.8,281,275.8Z"
                    style="fill: none; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 269.85px 293.65px;"
                    id="ellwb2q40dhh" class="animable"></path>
                <path
                    d="M240.49,311.5h28.69c-.24-5.78-1.06-17.58-3.82-20.5-1.58-1.69-4.28-.81-6.84.74C251.17,299.25,240.49,311.5,240.49,311.5Z"
                    style="fill: none; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 254.835px 300.791px;"
                    id="elo0gdv5k1nm" class="animable"></path>
                <path
                    d="M251.31,246.09s-4.6,5.53-4.6,6.68a5.46,5.46,0,0,1-1.38,3.91c-1.16,1.16-4.61,4.61-4.61,6.45s3.68,1.38,3.68,1.38-4.6,6-3.22,8.06,18.66,17.05,18.66,17.05l20-15.89-1.38-3a13.89,13.89,0,0,0,2.07-5.06c.23-2.31,1.85-10.83-6-16.36S254.77,243.1,251.31,246.09Z"
                    style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 260.771px 266.978px;"
                    id="el66pvz4d0cms" class="animable"></path>
                <path
                    d="M278.49,270.73a13.89,13.89,0,0,0,2.07-5.06c.23-2.31,1.85-10.83-6-16.36a29.16,29.16,0,0,0-12.8-4.74c1.72,1,5,3.16,5.2,5.2.23,2.77-2.76,3-2.76,3s-5.53,2.3-4.84,3.45,3.69,3.23,3.69,3.92-1.84,3.45-.23,3.91,2.53-3.45,4.84-3,3.22.23,2.53,3.91-2.76,4.61-2.76,5.3,7,1.94,11.36,1.12Z"
                    style="fill: rgb(38, 50, 56); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 270.076px 258.11px;"
                    id="el2wgtf3n5e14" class="animable"></path>
                <path d="M252.7,244.94s16.12-14.74,18.19-14.74,15.2,7.6,15.66,10.59-3.22,23.26-3.22,23.26Z"
                      style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 269.645px 247.125px;"
                      id="elj3d5hhf1q4f" class="animable"></path>
                <path
                    d="M252.7,244.94l30.63,19.11s.71-3.9,1.46-8.53l-26.94-15.2C254.94,242.89,252.7,244.94,252.7,244.94Z"
                    style="fill: rgb(38, 50, 56); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 268.745px 252.185px;"
                    id="elsfnul3ukgr" class="animable"></path>
                <path
                    d="M241.64,241.48s46.52,35,47.21,32.25-.46-6.91-3.68-10.83-21-15.2-29.25-18.88S242.1,238.72,241.64,241.48Z"
                    style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 265.341px 256.988px;"
                    id="ely4ti5e8wk9" class="animable"></path>
                <path
                    d="M251,256.09c-.57,2.15-1.79,3.7-2.71,3.45s-1.2-2.19-.62-4.34,1.79-3.69,2.71-3.45S251.6,254,251,256.09Z"
                    style="fill: none; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 249.339px 255.646px;"
                    id="elu5xiqr3lvce" class="animable"></path>
                <line x1="251.02" y1="256.09" x2="265.36" y2="261.75"
                      style="fill: none; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 258.19px 258.92px;"
                      id="elbz19hvbuc7a" class="animable"></line>
                <path d="M243.94,265.9a7.33,7.33,0,0,0,7.37-2.08"
                      style="fill: none; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 247.625px 264.997px;"
                      id="eljcgb8ebjjm" class="animable"></path>
                <line x1="250.62" y1="262.44" x2="252.7" y2="265.2"
                      style="fill: none; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 251.66px 263.82px;"
                      id="el9az9dfa0mzr" class="animable"></line>
                <polygon points="254.5 286 255.14 295.67 281.86 275.87 279.64 271.42 254.5 286"
                         style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 268.18px 283.545px;"
                         id="el27a88tl6vc9" class="animable"></polygon>
                <path d="M218.34,312.17l-4.65,1.31-6.83-24.28a2.42,2.42,0,0,1,1.68-3h0a2.42,2.42,0,0,1,3,1.67Z"
                      style="fill: rgb(38, 50, 56); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 212.553px 299.793px;"
                      id="el4gmt9m4a1at" class="animable"></path>
                <path
                    d="M224.17,299.56s-6.57-8.85-8.47-11.5-3.8-2.53-5.06-1.77-7.21,5.43-6.83,6.95,3.67,9,4.17,10a3.24,3.24,0,0,0,2.79,1.9c1.26,0,2.4-2.66,2.4-2.66h2s2.41,5.19,5.06,6.33a12.52,12.52,0,0,0,5.69.75l2.4,3.29h10.5Z"
                    style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 221.306px 299.334px;"
                    id="elm9isio47fhb" class="animable"></path>
                <path d="M208.74,304.12a2.21,2.21,0,0,1-.25-2.41c.63-1.51,2.66-4.55,3.16-4.55s4.93-.25,4.93-.25"
                      style="fill: none; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 212.412px 300.515px;"
                      id="elmr6bu5nytqo" class="animable"></path>
                <path d="M206.85,299.56s2.27-4.93,3.41-5.43,5.82-.51,5.82-.51"
                      style="fill: none; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 211.465px 296.59px;"
                      id="elb04die71ooi" class="animable"></path>
                <path d="M205.2,296.15s2.78-5.31,4.43-5.56a40.43,40.43,0,0,1,4.68-.26"
                      style="fill: none; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 209.755px 293.24px;"
                      id="ellxqs2xxx11g" class="animable"></path>
              </g>
              <path
                  d="M232,237h-3.2a25.87,25.87,0,0,0-24.31,17.05l-18.72,51.72a3.66,3.66,0,0,0,3.44,4.9H284a6.33,6.33,0,0,0,6.33-6.34V245.17a8.16,8.16,0,0,0-8.16-8.17Z"
                  style="fill: none; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 237.942px 273.835px;"
                  id="elz0ee741llho" class="animable"></path>
              <path
                  d="M299.67,243.4v62.27A5.33,5.33,0,0,0,305,311h51l-15-51a29.65,29.65,0,0,0-8.54-13.62h0a29.68,29.68,0,0,0-19.14-7.69l-8.6-.23A4.94,4.94,0,0,0,299.67,243.4Z"
                  style="fill: rgb(117, 117, 117); transform-origin: 327.835px 274.729px;" id="el2xr2h2mxpp"
                  class="animable"></path>
              <g style="clip-path: url(&quot;#freepik--clip-path-3--inject-11&quot;); transform-origin: 327.67px 286.31px;"
                 id="el7q7jmyo8rq5" class="animable">
                <path d="M341.49,261.62l-39.78,48.22A5.33,5.33,0,0,0,305,311h18.6l24.13-28.15Z"
                      style="fill: rgb(255, 255, 255); transform-origin: 324.72px 286.31px;" id="elf02spc18r5"
                      class="animable"></path>
                <polygon points="353.63 302.93 350.46 292.14 335.33 311 346.5 311 353.63 302.93"
                         style="fill: rgb(255, 255, 255); transform-origin: 344.48px 301.57px;" id="eltj79f8noayr"
                         class="animable"></polygon>
              </g>
              <path
                  d="M299.67,243.4v62.27A5.33,5.33,0,0,0,305,311h51l-15-51a29.65,29.65,0,0,0-8.54-13.62h0a29.68,29.68,0,0,0-19.14-7.69l-8.6-.23A4.94,4.94,0,0,0,299.67,243.4Z"
                  style="fill: none; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 327.835px 274.729px;"
                  id="elrsnte5gf4t" class="animable"></path>
              <path d="M221,238.21a25.84,25.84,0,0,0-16.51,15.84l-18.72,51.72a3.66,3.66,0,0,0,3.44,4.9H221Z"
                    style="fill: none; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 203.277px 274.44px;"
                    id="ele94ljjyj65b" class="animable"></path>
              <path d="M120.12,350.85s-3.45,2.48-3.45,5.48,2,7,4,7.67,2.4-2.25,2.4-2.25S120.25,354.69,120.12,350.85Z"
                    style="fill: rgb(38, 50, 56); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 119.87px 357.475px;"
                    id="el78rkompu3jm" class="animable"></path>
              <g id="elk06nvtym5z">
                <rect x="119.18" y="320.73" width="8.67" height="24.67" rx="2.83"
                      style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 123.515px 333.065px; transform: rotate(10.71deg);"
                      class="animable" id="eldze5ohepcpe"></rect>
              </g>
              <rect x="378.33" y="335" width="11.67" height="22.67" rx="4.67"
                    style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 384.165px 346.335px;"
                    id="elr82boo80dpf" class="animable"></rect>
              <circle cx="154.83" cy="371.5" r="31.17"
                      style="fill: rgb(38, 50, 56); transform-origin: 154.83px 371.5px;" id="elbv6kn9yphp"
                      class="animable"></circle>
              <g style="clip-path: url(&quot;#freepik--clip-path-4--inject-11&quot;); transform-origin: 156px 371.38px;"
                 id="el3ohwzkg3wtp" class="animable">
                <path d="M153.5,332l1.33,39.5L135,339ZM177,402.46l-22.16-31,4.23,39.3Z"
                      style="fill: rgb(255, 255, 255); transform-origin: 156px 371.38px;" id="elj3fkzwvig6"
                      class="animable"></path>
              </g>
              <circle cx="154.83" cy="371.5" r="31.17"
                      style="fill: none; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 154.83px 371.5px;"
                      id="elpmwqvl0kyp" class="animable"></circle>
              <circle cx="154.83" cy="371.5" r="20.5"
                      style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 154.83px 371.5px;"
                      id="eljbpavfhblvk" class="animable"></circle>
              <circle cx="154.83" cy="371.5" r="14.83"
                      style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 154.83px 371.5px;"
                      id="elf63jwx178f" class="animable"></circle>
              <g id="elyydxu9m0vs">
                <circle cx="330.83" cy="371.5" r="31.17"
                        style="fill: rgb(38, 50, 56); transform-origin: 330.83px 371.5px; transform: rotate(-61.53deg);"
                        class="animable" id="elftg2r9ygl8k"></circle>
              </g>
              <g style="clip-path: url(&quot;#freepik--clip-path-5--inject-11&quot;); transform-origin: 331.38px 372.375px;"
                 id="elzl0hs38wuxe" class="animable">
                <path d="M368.07,358.25,330.83,371.5l25-28.76Zm-60,43.76,22.78-30.51-36.16,15.94Z"
                      style="fill: rgb(255, 255, 255); transform-origin: 331.38px 372.375px;" id="el1yai5jqrylg"
                      class="animable"></path>
              </g>
              <g id="el15go02lg8bk">
                <circle cx="330.83" cy="371.5" r="31.17"
                        style="fill: none; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 330.83px 371.5px; transform: rotate(-61.53deg);"
                        class="animable" id="el1meylumcu5m"></circle>
              </g>
              <g id="elggvhpk6xaw">
                <circle cx="330.83" cy="371.5" r="20.5"
                        style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 330.83px 371.5px; transform: rotate(-65.08deg);"
                        class="animable" id="elz97ic7nngb"></circle>
              </g>
              <g id="elfd7kutv1q5o">
                <circle cx="330.83" cy="371.5" r="14.83"
                        style="fill: rgb(255, 255, 255); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 330.83px 371.5px; transform: rotate(-16.05deg);"
                        class="animable" id="elt9y4m0l2g9s"></circle>
              </g>
              <path
                  d="M190.47,304.42c2.41,5.33,3,10.29,1.22,11.08s-5.11-2.9-7.52-8.23-3-10.3-1.22-11.09S188.05,299.08,190.47,304.42Z"
                  style="fill: rgb(38, 50, 56); stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 187.32px 305.84px;"
                  id="elj3phytrj71" class="animable"></path>
            </g>
            <g id="freepik--Floor--inject-11" class="animable" style="transform-origin: 252.22px 402.67px;">
              <line x1="27.35" y1="402.67" x2="477.09" y2="402.67"
                    style="fill: none; stroke: rgb(38, 50, 56); stroke-linecap: round; stroke-linejoin: round; transform-origin: 252.22px 402.67px;"
                    id="elb6lm0rm0oja" class="animable"></line>
            </g>
            <defs>
              <filter id="active" height="200%">
                <feMorphology in="SourceAlpha" result="DILATED" operator="dilate" radius="2"></feMorphology>
                <feFlood flood-color="#32DFEC" flood-opacity="1" result="PINK"></feFlood>
                <feComposite in="PINK" in2="DILATED" operator="in" result="OUTLINE"></feComposite>
                <feMerge>
                  <feMergeNode in="OUTLINE"></feMergeNode>
                  <feMergeNode in="SourceGraphic"></feMergeNode>
                </feMerge>
              </filter>
              <filter id="hover" height="200%">
                <feMorphology in="SourceAlpha" result="DILATED" operator="dilate" radius="2"></feMorphology>
                <feFlood flood-color="#ff0000" flood-opacity="0.5" result="PINK"></feFlood>
                <feComposite in="PINK" in2="DILATED" operator="in" result="OUTLINE"></feComposite>
                <feMerge>
                  <feMergeNode in="OUTLINE"></feMergeNode>
                  <feMergeNode in="SourceGraphic"></feMergeNode>
                </feMerge>
                <feColorMatrix type="matrix"
                               values="0   0   0   0   0                0   1   0   0   0                0   0   0   0   0                0   0   0   1   0 "></feColorMatrix>
              </filter>
            </defs>
            <defs>
              <clipPath id="freepik--clip-path--inject-11">
                <path
                    d="M232,237h-3.2a25.87,25.87,0,0,0-24.31,17.05l-18.72,51.72a3.66,3.66,0,0,0,3.44,4.9H284a6.33,6.33,0,0,0,6.33-6.34V245.17a8.16,8.16,0,0,0-8.16-8.17Z"
                    style="fill:#757575;stroke:#263238;stroke-linecap:round;stroke-linejoin:round"></path>
              </clipPath>
              <clipPath id="freepik--clip-path-2--inject-11">
                <path
                    d="M281,275.8s9.68,7.83,12.21,13.59,6,22.11,6,22.11H240.49s15.66-18,22.11-23.72S281,275.8,281,275.8Z"
                    style="fill:#fff;stroke:#263238;stroke-linecap:round;stroke-linejoin:round"></path>
              </clipPath>
              <clipPath id="freepik--clip-path-3--inject-11">
                <path
                    d="M299.67,243.4v62.27A5.33,5.33,0,0,0,305,311h51l-15-51a29.65,29.65,0,0,0-8.54-13.62h0a29.68,29.68,0,0,0-19.14-7.69l-8.6-.23A4.94,4.94,0,0,0,299.67,243.4Z"
                    style="fill:#757575;stroke:#263238;stroke-linecap:round;stroke-linejoin:round"></path>
              </clipPath>
              <clipPath id="freepik--clip-path-4--inject-11">
                <circle cx="154.83" cy="371.5" r="31.17"
                        style="fill:#263238;stroke:#263238;stroke-linecap:round;stroke-linejoin:round"></circle>
              </clipPath>
              <clipPath id="freepik--clip-path-5--inject-11">
                <circle cx="330.83" cy="371.5" r="31.17" transform="translate(-153.44 485.27) rotate(-61.53)"
                        style="fill:#263238;stroke:#263238;stroke-linecap:round;stroke-linejoin:round"></circle>
              </clipPath>
            </defs>
          </svg>
        </div>
      </div>
    </div>
    <p class="app-version">V {{ app_version }}</p>
  </section>
</template>

<script>
import {toast} from 'vue3-toastify';
import axios from "axios";

export default {
  name: "LoginPage",
  data() {
    return {
      login: {
        username: "",
        password: "",
        show: false
      },
      loading: false,
      app_version: this.$store.state.app_version
    }
  },
  methods: {
    loginSubmit() {
      this.loading = true;
      if (!this.login.username) {
        toast.error("لطفا نام کاربری را وارد کنید", {
          autoClose: 6000,
          position: "top-right",
          rtl: false,
          closeOnClick: true
        });
      } else if (!this.login.password) {
        toast.error("لطفا کلمه عبور را وارد کنید", {
          autoClose: 6000,
          position: "top-right",
          rtl: false,
          closeOnClick: true
        });
      } else {
        this.$http.post("api/v1/user/login/", this.login, {
          headers: {
            "Content-Type": "application/json",
            "Authorization": "",
          }
        }).then((r) => {
          toast.success(r.data.message, {
            autoClose: 6000,
            position: "top-right",
            rtl: false,
            closeOnClick: true
          });
          const access_token = `JWT ${r.data.data.access}`;
          this.$store.state.user.access_token = access_token;
          this.$store.state.user.first_name = r.data.data.first_name;
          this.$store.state.user.last_name = r.data.data.last_name;
          localStorage.setItem("access_token", access_token);
          axios.defaults.headers.post['Authorization'] = access_token;
          axios.defaults.headers.get['Authorization'] = access_token;
          this.$router.push('/single');
        }).catch((e) => {
          toast.error(e.response.data.message, {
            autoClose: 6000,
            position: "top-right",
            rtl: false,
            closeOnClick: true
          });
        }).finally(() => {
          this.loading = false;
        })
      }
    },
    passKeyUp(e) {
      if (e.code === "Enter" || e.code === "NumpadEnter") {
        this.loginSubmit();
      }
    },
  }
}
</script>

<style scoped>
.login-btn {
  transition: all .3s !important;
}

.app-version {
  position: fixed;
  bottom: 10px;
  right: 10px;
}

.bg-image-vertical {
  position: relative;
  overflow: hidden;
  background-repeat: no-repeat;
  background-position: right center;
  background-size: auto 100%;
}

.direction-ltr {
  direction: ltr !important;
}

.overflow-hidden {
  overflow: hidden !important;
}

.vpd-input-group {
  height: 38px !important;
  width: 100% !important;
}

.cursor-pointer {
  cursor: pointer;
}

svg#freepik_stories-trip:not(.animated) .animable {
  opacity: 0;
}

svg#freepik_stories-trip.animated #freepik--Clouds--inject-11 {
  animation: 1.5s Infinite linear wind;
  animation-delay: 0s;
}

svg#freepik_stories-trip.animated #freepik--Car--inject-11 {
  animation: 3s Infinite linear shake;
  animation-delay: 0s;
}

@keyframes wind {
  0% {
    transform: rotate(0deg);
  }
  25% {
    transform: rotate(1deg);
  }
  75% {
    transform: rotate(-1deg);
  }
}

@keyframes shake {
  10%, 90% {
    transform: translate3d(-1px, 0, 0);
  }
  20%, 80% {
    transform: translate3d(2px, 0, 0);
  }
  30%, 50%, 70% {
    transform: translate3d(-4px, 0, 0);
  }
  40%, 60% {
    transform: translate3d(4px, 0, 0);
  }
}
</style>