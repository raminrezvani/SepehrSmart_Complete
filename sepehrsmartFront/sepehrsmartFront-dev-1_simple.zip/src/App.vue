<template>
  <div v-if="loading" class="vh-100 d-flex justify-content-center align-items-center">
    <svg class="animated w-25" id="freepik_stories-campfire" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500"
         version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs">
      <g id="freepik--background-complete--inject-1" class="animable" style="transform-origin: 250px 228.23px;">
        <rect y="382.4" width="500" height="0.25" style="fill: rgb(235, 235, 235); transform-origin: 250px 382.525px;"
              id="elo1cwrjc8zhb" class="animable"></rect>
        <rect x="52.46" y="391.92" width="16.06" height="0.25"
              style="fill: rgb(235, 235, 235); transform-origin: 60.49px 392.045px;" id="elngpik0alug"
              class="animable"></rect>
        <rect x="171.14" y="389.21" width="53.53" height="0.25"
              style="fill: rgb(235, 235, 235); transform-origin: 197.905px 389.335px;" id="elzfhdlpbyifg"
              class="animable"></rect>
        <rect x="69.52" y="401.21" width="36.25" height="0.25"
              style="fill: rgb(235, 235, 235); transform-origin: 87.645px 401.335px;" id="el69w8hinf1nn"
              class="animable"></rect>
        <rect x="379.14" y="389.08" width="43.19" height="0.25"
              style="fill: rgb(235, 235, 235); transform-origin: 400.735px 389.205px;" id="elb830kvre5g"
              class="animable"></rect>
        <rect x="431.24" y="389.08" width="6.33" height="0.25"
              style="fill: rgb(235, 235, 235); transform-origin: 434.405px 389.205px;" id="el8zcab521337"
              class="animable"></rect>
        <rect x="317" y="395.31" width="53.89" height="0.25"
              style="fill: rgb(235, 235, 235); transform-origin: 343.945px 395.435px;" id="el2rsbxtfzmm1"
              class="animable"></rect>
        <path
            d="M237,337.8H43.91a5.71,5.71,0,0,1-5.7-5.71V60.66A5.71,5.71,0,0,1,43.91,55H237a5.71,5.71,0,0,1,5.71,5.71V332.09A5.71,5.71,0,0,1,237,337.8ZM43.91,55.2a5.46,5.46,0,0,0-5.45,5.46V332.09a5.46,5.46,0,0,0,5.45,5.46H237a5.47,5.47,0,0,0,5.46-5.46V60.66A5.47,5.47,0,0,0,237,55.2Z"
            style="fill: rgb(235, 235, 235); transform-origin: 140.46px 196.4px;" id="elc7sr5u6arrw"
            class="animable"></path>
        <path
            d="M453.31,337.8H260.21a5.72,5.72,0,0,1-5.71-5.71V60.66A5.72,5.72,0,0,1,260.21,55h193.1A5.71,5.71,0,0,1,459,60.66V332.09A5.71,5.71,0,0,1,453.31,337.8ZM260.21,55.2a5.47,5.47,0,0,0-5.46,5.46V332.09a5.47,5.47,0,0,0,5.46,5.46h193.1a5.47,5.47,0,0,0,5.46-5.46V60.66a5.47,5.47,0,0,0-5.46-5.46Z"
            style="fill: rgb(235, 235, 235); transform-origin: 356.75px 196.4px;" id="elp06gt4vz67i"
            class="animable"></path>
        <path
            d="M158.57,109.79A27.47,27.47,0,0,0,211,121.23a27.18,27.18,0,0,1-11.44,2.5,27.47,27.47,0,0,1-25-38.92A27.45,27.45,0,0,0,158.57,109.79Z"
            style="fill: rgb(240, 240, 240); transform-origin: 184.785px 111.019px;" id="elourxdye3mjf"
            class="animable"></path>
        <path
            d="M176.46,124.44H72.72s-22.88-33.08,4-49.24,40.66,28.1,40.66,28.1,4.37-7,17.92-4.23,7.72,10.7,7.72,10.7,10.94-5.47,18.83-3.23S165,117.85,165,117.85,180.05,119.22,176.46,124.44Z"
            style="fill: rgb(250, 250, 250); transform-origin: 120.327px 98.0452px;" id="el49v9jdgi3z7"
            class="animable"></path>
        <path
            d="M440.86,124.72H345.21a24.63,24.63,0,0,1,17.2-14.89c-8.65-7.44,19.11-23.13,38.62-1.41,0-7.24,21.93-4.62,26.15,5.23C431.41,107.22,449.91,118.48,440.86,124.72Z"
            style="fill: rgb(250, 250, 250); transform-origin: 394.266px 111.04px;" id="el7taj3cjbpsj"
            class="animable"></path>
        <path
            d="M479.08,382.4H19s33.46-70.51,92-54.57c53.81-73,103.78-63.06,153.06-15.94,38.72-35.19,71.7-16.94,66.5,35.34C358.71,321.62,444.09,337.84,479.08,382.4Z"
            style="fill: rgb(235, 235, 235); transform-origin: 249.04px 328.593px;" id="elu6iwejkv9vr"
            class="animable"></path>
        <polygon points="67.27 323.11 62.27 342.36 72.27 342.36 67.27 323.11"
                 style="fill: rgb(224, 224, 224); transform-origin: 67.27px 332.735px;" id="elxe580p2g4a8"
                 class="animable"></polygon>
        <polygon points="81.13 316.48 77.33 331.07 84.92 331.07 81.13 316.48"
                 style="fill: rgb(224, 224, 224); transform-origin: 81.125px 323.775px;" id="elcoa0txnlsn"
                 class="animable"></polygon>
        <polygon points="91.41 316.48 88.49 327.47 94.33 327.47 91.41 316.48"
                 style="fill: rgb(224, 224, 224); transform-origin: 91.41px 321.975px;" id="el3jg7mtrjkrr"
                 class="animable"></polygon>
        <polygon points="107.76 323.41 105.84 330.65 109.69 330.65 107.76 323.41"
                 style="fill: rgb(224, 224, 224); transform-origin: 107.765px 327.03px;" id="elj573dlez0jj"
                 class="animable"></polygon>
        <polygon points="98.49 339.63 96.56 346.87 100.41 346.87 98.49 339.63"
                 style="fill: rgb(224, 224, 224); transform-origin: 98.485px 343.25px;" id="elf2bsqbr7l8l"
                 class="animable"></polygon>
        <polygon points="145.46 278.9 140.46 298.15 150.46 298.15 145.46 278.9"
                 style="fill: rgb(224, 224, 224); transform-origin: 145.46px 288.525px;" id="elr9my44hdzv"
                 class="animable"></polygon>
        <polygon points="283.3 284.9 278.3 304.15 288.3 304.15 283.3 284.9"
                 style="fill: rgb(224, 224, 224); transform-origin: 283.3px 294.525px;" id="el0n4f4vj0o05m"
                 class="animable"></polygon>
        <polygon points="169.4 270.31 165.61 284.9 173.19 284.9 169.4 270.31"
                 style="fill: rgb(224, 224, 224); transform-origin: 169.4px 277.605px;" id="el6q4y4eqdt68"
                 class="animable"></polygon>
        <polygon points="184.8 269.27 181.88 280.26 187.72 280.26 184.8 269.27"
                 style="fill: rgb(224, 224, 224); transform-origin: 184.8px 274.765px;" id="elbltug49y14"
                 class="animable"></polygon>
        <polygon points="305.47 287.16 302.54 298.15 308.39 298.15 305.47 287.16"
                 style="fill: rgb(224, 224, 224); transform-origin: 305.465px 292.655px;" id="el6o0i3kw7fal"
                 class="animable"></polygon>
        <polygon points="379.14 331.07 377.22 338.31 381.06 338.31 379.14 331.07"
                 style="fill: rgb(224, 224, 224); transform-origin: 379.14px 334.69px;" id="elsa0wtfzwkji"
                 class="animable"></polygon>
        <polygon points="318.92 296.92 317 304.15 320.85 304.15 318.92 296.92"
                 style="fill: rgb(224, 224, 224); transform-origin: 318.925px 300.535px;" id="ell8h7qxluf6m"
                 class="animable"></polygon>
        <polygon points="240.8 345.81 238.87 353.04 242.72 353.04 240.8 345.81"
                 style="fill: rgb(224, 224, 224); transform-origin: 240.795px 349.425px;" id="elmetypy3r52"
                 class="animable"></polygon>
        <polygon points="436.43 343.01 433.15 355.37 439.72 355.37 436.43 343.01"
                 style="fill: rgb(224, 224, 224); transform-origin: 436.435px 349.19px;" id="el1qlcwb6871u"
                 class="animable"></polygon>
        <polygon points="356.76 330.65 353.48 343.01 360.05 343.01 356.76 330.65"
                 style="fill: rgb(224, 224, 224); transform-origin: 356.765px 336.83px;" id="elt25ggnljo4m"
                 class="animable"></polygon>
        <polygon points="204.69 313.61 202.77 320.85 206.62 320.85 204.69 313.61"
                 style="fill: rgb(224, 224, 224); transform-origin: 204.695px 317.23px;" id="elastqgvxe1g6"
                 class="animable"></polygon>
        <polygon points="164.09 316.93 160.8 329.29 167.37 329.29 164.09 316.93"
                 style="fill: rgb(224, 224, 224); transform-origin: 164.085px 323.11px;" id="el0vawgjlbmgk"
                 class="animable"></polygon>
        <polygon points="227.95 280.26 224.67 292.63 231.24 292.63 227.95 280.26"
                 style="fill: rgb(224, 224, 224); transform-origin: 227.955px 286.445px;" id="eld0vyejjx63r"
                 class="animable"></polygon>
        <path
            d="M333.29,179.46H279.83s-11.45-4-7-14.4,21-1.74,21-1.74-1.74-14.59,15.45-10.45,15,18.59,15,18.59S349.4,168,333.29,179.46Z"
            style="fill: rgb(250, 250, 250); transform-origin: 305.243px 165.795px;" id="elr76bt6ssr7"
            class="animable"></path>
      </g>
      <g id="freepik--Shadow--inject-1" class="animable" style="transform-origin: 250px 416.24px;">
        <ellipse id="freepik--path--inject-1" cx="250" cy="416.24" rx="193.89" ry="11.32"
                 style="fill: rgb(245, 245, 245); transform-origin: 250px 416.24px;" class="animable"></ellipse>
      </g>
      <g id="freepik--Fire--inject-1" class="animable" style="transform-origin: 335.95px 334.708px;">
        <path
            d="M327.77,383.82l-48.72,13.76a6.81,6.81,0,0,0-4.69,8.38h0a6.82,6.82,0,0,0,8.38,4.69l48.72-13.75a6.83,6.83,0,0,0,4.69-8.39h0A6.82,6.82,0,0,0,327.77,383.82Z"
            style="fill: rgb(38, 50, 56); transform-origin: 305.254px 397.235px;" id="eljvt24mq8vaj"
            class="animable"></path>
        <g id="el8abuywhm2va">
          <path
              d="M327.77,383.82l-5.44,1.54a6.8,6.8,0,0,0-4.69,8.38h0a6.8,6.8,0,0,0,8.38,4.69l5.44-1.53a6.83,6.83,0,0,0,4.69-8.39h0A6.82,6.82,0,0,0,327.77,383.82Z"
              style="fill: rgb(255, 255, 255); opacity: 0.4; transform-origin: 326.893px 391.127px;"
              class="animable"></path>
        </g>
        <g id="elorab0vk41v7">
          <path d="M346.09,308c-.85-1.67-1.76-3.41-2.79-5.34l1-.55c1,1.93,1.95,3.68,2.8,5.36Z"
                style="fill: rgb(64, 123, 255); opacity: 0.9; transform-origin: 345.2px 305.055px;"
                class="animable"></path>
        </g>
        <g id="elh5p9i0j247s">
          <path d="M339.26,295.23c-8.68-15.71-13.13-28.46-13.6-39l1.17-.06c.46,10.2,5,23.14,13.46,38.47Z"
                style="fill: rgb(64, 123, 255); opacity: 0.9; transform-origin: 332.975px 275.7px;"
                class="animable"></path>
        </g>
        <g id="eltnxkuhwwwfo">
          <path
              d="M333.81,394.53c-28.8,0-38.68-24.5-28-44.86,9.35-17.75,5-37.6.32-47.52,10.56,8.48,16.8,22.24,16.8,22.24s-8.59-28.33,3.62-49.52c2.94,15,30.4,47.6,25.87,69.68,5.07-6.72,4.59-22,3.47-29.4C371.28,339.91,375,394.53,333.81,394.53Z"
              style="fill: rgb(64, 123, 255); opacity: 0.9; transform-origin: 334.133px 334.7px;"
              class="animable"></path>
        </g>
        <g id="elbs4qymnp8w">
          <path
              d="M334.18,389.83c16.67-1.23,21.34-15.85,14.26-27.18-6.17-9.87-4.48-21.55-2.22-27.5-5.75,5.37-8.77,13.6-8.77,13.6s3.75-16.77-4.23-28.52c-1.05,8.79-15.56,28.87-12,41.46C318,358,317.64,349.14,318,344.81,310.14,359.81,310.34,391.59,334.18,389.83Z"
              style="fill: rgb(255, 255, 255); opacity: 0.3; transform-origin: 332.502px 355.065px;"
              class="animable"></path>
        </g>
        <path
            d="M344.13,385.33l48.72,13.76a6.81,6.81,0,0,1,4.69,8.38h0a6.81,6.81,0,0,1-8.38,4.69l-48.72-13.75a6.83,6.83,0,0,1-4.69-8.39h0A6.82,6.82,0,0,1,344.13,385.33Z"
            style="fill: rgb(38, 50, 56); transform-origin: 366.646px 398.746px;" id="el0eanedz5cz57"
            class="animable"></path>
        <path
            d="M337.58,387.29l19.49,13.47a6.82,6.82,0,0,1,2,9.4h0a6.81,6.81,0,0,1-9.39,2l-19.9-13.75a6.81,6.81,0,0,1-1.66-9.46h0A6.81,6.81,0,0,1,337.58,387.29Z"
            style="fill: rgb(38, 50, 56); transform-origin: 343.526px 399.656px;" id="ell8xb9n4phhg"
            class="animable"></path>
      </g>
      <g id="freepik--Character--inject-1" class="animable" style="transform-origin: 194.116px 285.401px;">
        <path
            d="M221.06,401.2h-15.3a1,1,0,0,0-1,.93l-.94,12.11a2.38,2.38,0,0,0,2.35,2.42c5.33-.09,7.88-.41,14.61-.41,4.14,0,4.06.43,9.78.43s5.5-5.19,3.23-6.16c-6.32-2.71-7.76-6-10.37-8.48A3.31,3.31,0,0,0,221.06,401.2Z"
            style="fill: rgb(64, 123, 255); transform-origin: 219.55px 408.938px;" id="elpnxkd61dcn"
            class="animable"></path>
        <path
            d="M165,298.57c16.46-6.41,40.88-10.61,45.49,7.62,8.68,34.37,9.33,72.93,9.33,72.93l-20.47,3.45s-11.47-27.83-13.47-55.69c-7.74,4.62-27.35,12.17-41.59,3.14-12-7.64-11.55-18.8-9.75-31.22C134.55,298.8,140.42,297.35,165,298.57Z"
            style="fill: rgb(38, 50, 56); transform-origin: 176.702px 337.832px;" id="el34mdv6ayz33"
            class="animable"></path>
        <g id="elkejwk02xxg">
          <path d="M210.5,306.19l-24.61,20.69c2,27.86,13.47,55.69,13.47,55.69l20.47-3.45S219.18,340.56,210.5,306.19Z"
                style="opacity: 0.6; transform-origin: 202.86px 344.38px;" class="animable"></path>
        </g>
        <path d="M223.64,404l-18.15,2.23-10.4-28.92a1.39,1.39,0,0,1,1-1.84L219.62,371a1.39,1.39,0,0,1,1.64,1.27Z"
              style="fill: rgb(64, 123, 255); transform-origin: 209.322px 388.603px;" id="el9wasd46brlf"
              class="animable"></path>
        <path
            d="M163.2,180.55c-.47,8.57.18,29.25-6.81,34.06,0,0-1.45,6.81,13.49,8.83,16.43,2.23,9.93-7.41,9.93-7.41-5.74-3-4.88-14.9-1.73-21.18Z"
            style="fill: rgb(255, 139, 123); transform-origin: 168.715px 202.162px;" id="eladdk3kkqa5r"
            class="animable"></path>
        <path
            d="M193.38,177.3a.6.6,0,0,1-.26-.14.64.64,0,0,1-.07-.91,6.37,6.37,0,0,1,5.41-2.33.65.65,0,0,1-.17,1.28h0a5.1,5.1,0,0,0-4.26,1.89A.68.68,0,0,1,193.38,177.3Z"
            style="fill: rgb(38, 50, 56); transform-origin: 195.921px 175.609px;" id="elb8pn89txqin"
            class="animable"></path>
        <path d="M196.44,184.38s1.27,4.92,3,7.44c-1.61,1.17-4,.25-4,.25Z"
              style="fill: rgb(255, 86, 82); transform-origin: 197.44px 188.397px;" id="eljpo3ngx7gp"
              class="animable"></path>
        <path d="M195.69,182.39c-.13,1.09.34,2,1.05,2.13s1.4-.72,1.53-1.81-.33-2.05-1-2.14S195.83,181.3,195.69,182.39Z"
              style="fill: rgb(38, 50, 56); transform-origin: 196.98px 182.548px;" id="el7gghlstiyh"
              class="animable"></path>
        <path
            d="M271.26,401.2H256a1,1,0,0,0-1,.93L254,414.24a2.37,2.37,0,0,0,2.34,2.42c5.33-.09,7.88-.41,14.61-.41,4.14,0,10.22.43,15.94.43s5.64-5.65,3.23-6.16c-10.83-2.3-12.72-5.46-16.52-8.48A3.77,3.77,0,0,0,271.26,401.2Z"
            style="fill: rgb(64, 123, 255); transform-origin: 272.836px 408.94px;" id="el71ufk7swbbb"
            class="animable"></path>
        <path
            d="M187.23,298.57c16.45-6.41,68.85-10.61,73.46,7.62,8.69,34.37,9.33,72.93,9.33,72.93l-20.46,3.45s-11.47-27.83-13.48-55.69c-24.27,1.3-62.88,14.31-77.12,5.27-12-7.64-17.73-20.93-15.92-33.35A399.11,399.11,0,0,1,187.23,298.57Z"
            style="fill: rgb(38, 50, 56); transform-origin: 206.366px 337.832px;" id="eltskt6mr6sm"
            class="animable"></path>
        <path d="M244.75,254.92l6.15-8.63-10.7-4.76s-4.37,7.54-3.07,13.05l1.16,1A4.35,4.35,0,0,0,244.75,254.92Z"
              style="fill: rgb(255, 139, 123); transform-origin: 243.894px 249.125px;" id="elmfjgi4sw4u"
              class="animable"></path>
        <polygon points="255.48 239.52 247.39 236.35 240.2 241.53 250.9 246.29 255.48 239.52"
                 style="fill: rgb(255, 139, 123); transform-origin: 247.84px 241.32px;" id="eljopc17mvcyh"
                 class="animable"></polygon>
        <path
            d="M163.69,223.14l4.07,3.89,4.21,4c2.83,2.62,5.67,5.22,8.53,7.7s5.75,4.84,8.59,7a66.5,66.5,0,0,0,8.19,5.35l.89.45.8.37c.23.08.46.18.69.28s.5.16.75.25a18.93,18.93,0,0,0,3.67.68,38.71,38.71,0,0,0,9.47-.63,84.09,84.09,0,0,0,10.58-2.62c1.78-.58,3.61-1.15,5.41-1.81.9-.32,1.81-.64,2.7-1l2.58-1L242.37,257c-1,.9-1.71,1.61-2.58,2.37s-1.71,1.44-2.58,2.15c-1.76,1.36-3.55,2.71-5.44,3.93A73.13,73.13,0,0,1,219.61,272,51.78,51.78,0,0,1,205,275.86a38.93,38.93,0,0,1-8.56,0c-.75-.11-1.49-.2-2.25-.35l-2.28-.5-2.1-.62c-.68-.22-1.31-.45-2-.68A71.36,71.36,0,0,1,174.67,267a126,126,0,0,1-11-7.75c-3.47-2.71-6.78-5.52-10-8.43-1.59-1.47-3.17-2.93-4.7-4.46-.77-.76-1.55-1.52-2.3-2.31l-2.32-2.47Z"
            style="fill: rgb(64, 123, 255); transform-origin: 193.36px 249.618px;" id="eli08yns6nzyb"
            class="animable"></path>
        <g id="elm83huazx7he">
          <path
              d="M163.69,223.14l4.07,3.89,4.21,4c2.83,2.62,5.67,5.22,8.53,7.7s5.75,4.84,8.59,7a66.5,66.5,0,0,0,8.19,5.35l.89.45.8.37c.23.08.46.18.69.28s.5.16.75.25a18.93,18.93,0,0,0,3.67.68,38.71,38.71,0,0,0,9.47-.63,84.09,84.09,0,0,0,10.58-2.62c1.78-.58,3.61-1.15,5.41-1.81.9-.32,1.81-.64,2.7-1l2.58-1L242.37,257c-1,.9-1.71,1.61-2.58,2.37s-1.71,1.44-2.58,2.15c-1.76,1.36-3.55,2.71-5.44,3.93A73.13,73.13,0,0,1,219.61,272,51.78,51.78,0,0,1,205,275.86a38.93,38.93,0,0,1-8.56,0c-.75-.11-1.49-.2-2.25-.35l-2.28-.5-2.1-.62c-.68-.22-1.31-.45-2-.68A71.36,71.36,0,0,1,174.67,267a126,126,0,0,1-11-7.75c-3.47-2.71-6.78-5.52-10-8.43-1.59-1.47-3.17-2.93-4.7-4.46-.77-.76-1.55-1.52-2.3-2.31l-2.32-2.47Z"
              style="opacity: 0.2; transform-origin: 193.36px 249.618px;" class="animable"></path>
        </g>
        <path
            d="M192,215.1c-3.08-.61-6.41-1.21-9.61-1.66-8.13-1.15-15.77-1.23-25.09-1.25-2.23,0-4.45.07-6.59.17-7.37.38-14.94,6.57-16.65,13.75-5.27,22.08-5.57,62.07-2.73,84.1a5.64,5.64,0,0,0,6.45,4.84l57.06-8.88a5.61,5.61,0,0,0,4.75-5.54c0-19.24,3.77-55.92,4.66-66.48C205,225.3,200.71,216.82,192,215.1Z"
            style="fill: rgb(64, 123, 255); transform-origin: 166.94px 263.653px;" id="elm59sapovz"
            class="animable"></path>
        <g id="elaif6lvapmy">
          <path d="M191,248.22a49.74,49.74,0,0,0,10.33,19c.31-3.9.64-7.74.95-11.37Z"
                style="opacity: 0.1; transform-origin: 196.64px 257.72px;" class="animable"></path>
        </g>
        <path d="M278.82,259.47l5-9.35-11.22-3.36s-3.38,8-1.39,13.34l1.28.89A4.37,4.37,0,0,0,278.82,259.47Z"
              style="fill: rgb(255, 139, 123); transform-origin: 277.201px 254.262px;" id="elncpg69n7kx7"
              class="animable"></path>
        <polygon points="287.5 242.82 279.07 240.71 272.6 246.76 283.82 250.12 287.5 242.82"
                 style="fill: rgb(255, 139, 123); transform-origin: 280.05px 245.415px;" id="elgbdtbbwqqjn"
                 class="animable"></polygon>
        <path
            d="M201.22,221.75l3.64,4.29,3.78,4.4c2.54,2.9,5.1,5.78,7.69,8.54s5.23,5.4,7.83,7.86a65.57,65.57,0,0,0,7.6,6.16l.83.54.77.45.65.35c.22.12.48.21.72.33a20,20,0,0,0,3.59,1.06,39.14,39.14,0,0,0,9.47.34,84,84,0,0,0,10.8-1.53c1.83-.39,3.71-.76,5.56-1.24.93-.22,1.87-.45,2.79-.7l2.67-.68,6.39,11.6c-1.05.79-1.87,1.42-2.81,2.08s-1.85,1.26-2.79,1.87c-1.89,1.18-3.81,2.34-5.81,3.36a73,73,0,0,1-12.77,5.28,52.07,52.07,0,0,1-14.93,2.33,38.64,38.64,0,0,1-8.51-.92c-.73-.18-1.46-.34-2.2-.57l-2.22-.74-2-.83c-.65-.28-1.25-.58-1.88-.88a71.38,71.38,0,0,1-12.42-8,129.55,129.55,0,0,1-10.16-8.84q-4.75-4.58-9.05-9.41c-1.43-1.62-2.85-3.25-4.22-4.92-.68-.84-1.38-1.67-2-2.53l-2.06-2.7Z"
            style="fill: rgb(64, 123, 255); transform-origin: 228.085px 250.095px;" id="elry554gbgz6"
            class="animable"></path>
        <path
            d="M159.49,174.13c-.83,13.49-1.47,19.18,4.45,26.89,8.9,11.59,25.66,9.66,30.5-3.31,4.36-11.68,5-31.79-7.47-38.73A18.44,18.44,0,0,0,159.49,174.13Z"
            style="fill: rgb(255, 139, 123); transform-origin: 178.123px 182.639px;" id="elc900lolcoha"
            class="animable"></path>
        <path
            d="M193.89,177.77c.63,4,.37,8.69-5.39,7.91-14.84,10.39-22.23,11.39-22.23,11.39s-11.54-1.35-9-8.38-.58-12.84-.06-16.48,5.27-14.41,12.32-17.07a21.1,21.1,0,0,1,22.79,6.16C198.27,168.27,193.89,177.77,193.89,177.77Z"
            style="fill: rgb(38, 50, 56); transform-origin: 176.174px 175.537px;" id="el118cqogha6q"
            class="animable"></path>
        <path
            d="M191.54,180.63a11.3,11.3,0,0,1,.28,7.54c-1,3.24-4,2.83-5.71.23-1.56-2.35-2.89-6.86-.87-9.3S190.35,177.74,191.54,180.63Z"
            style="fill: rgb(255, 139, 123); transform-origin: 188.275px 184.112px;" id="elllkxrqzzwbk"
            class="animable"></path>
        <path
            d="M197,173.3c-.28,4.8-10.67,14.53-27,16.2s-14.13,1.45-14.2-7.18a75,75,0,0,1,.32-10.08,9.71,9.71,0,0,1,1.67-3.67s-8.62-.38-4.22-8.18c3.39-6,17-9.91,27.56-7.57C190.66,154.94,197.69,161.39,197,173.3Z"
            style="fill: rgb(64, 123, 255); transform-origin: 174.683px 171.225px;" id="elc3afu1j8qde"
            class="animable"></path>
        <g id="elcer4jqgngfg">
          <path
              d="M157.74,168.57a10.6,10.6,0,0,0-1.31,2.39c3.68-.53,10.9-2.06,14.29-6.06A29.69,29.69,0,0,1,157.74,168.57Z"
              style="opacity: 0.2; transform-origin: 163.575px 167.93px;" class="animable"></path>
        </g>
        <path d="M273.83,404l-18.15,2.23-10.4-28.92a1.39,1.39,0,0,1,1.06-1.84L269.81,371a1.4,1.4,0,0,1,1.65,1.27Z"
              style="fill: rgb(64, 123, 255); transform-origin: 259.514px 388.603px;" id="elzitfh092z2"
              class="animable"></path>
        <path
            d="M161,210.76c-5.51-.45-13.74-1.39-20.21,3.89s-9,16.73-9.2,21.78,14,6.8,24.7,7.52c18.84,1.28,22.18.44,30-10.16,4.66-6.28,7.14-18,4.82-19.17S169.48,211.44,161,210.76Z"
            style="fill: rgb(64, 123, 255); transform-origin: 161.79px 227.4px;" id="elmdkudtx2vt"
            class="animable"></path>
        <g id="el2ypr2xpidna">
          <g style="opacity: 0.2; transform-origin: 161.79px 227.4px;" class="animable">
            <path
                d="M161,210.76c-5.51-.45-13.74-1.39-20.21,3.89s-9,16.73-9.2,21.78,14,6.8,24.7,7.52c18.84,1.28,22.18.44,30-10.16,4.66-6.28,7.14-18,4.82-19.17S169.48,211.44,161,210.76Z"
                id="el669tmn5qi0m" class="animable" style="transform-origin: 161.79px 227.4px;"></path>
          </g>
        </g>
        <path
            d="M185.74,213.46a18.76,18.76,0,0,0-11.67-12.6c-9.91-3.9-23.85-3.8-31.36-.56s-13.63,15.26-4.72,20.27,26.84,5,33.63,1.33S181.38,213.37,185.74,213.46Z"
            style="fill: rgb(38, 50, 56); transform-origin: 159.656px 211.204px;" id="el8z79mtzs8ky"
            class="animable"></path>
        <polygon
            points="240.86 418.67 96.56 418.67 109.33 359.44 123.29 355.92 129.54 322.95 192.92 327.18 229.64 363.25 229.64 387.77 240.86 418.67"
            style="fill: rgb(64, 123, 255); transform-origin: 168.71px 370.81px;" id="el7uhyd4g4yf"
            class="animable"></polygon>
        <g id="eljzh2zbffp29">
          <polygon
              points="240.86 418.67 96.56 418.67 109.33 359.44 123.29 355.92 129.54 322.95 192.92 327.18 229.64 363.25 229.64 387.77 240.86 418.67"
              style="fill: rgb(255, 255, 255); opacity: 0.7; transform-origin: 168.71px 370.81px;"
              class="animable"></polygon>
        </g>
        <g id="elhqimam8kxnt">
          <polygon points="123.29 355.92 109.33 359.44 127.66 362.15 123.29 355.92"
                   style="fill: rgb(64, 123, 255); opacity: 0.7; transform-origin: 118.495px 359.035px;"
                   class="animable"></polygon>
        </g>
        <g id="elvxeqqmg1sea">
          <polygon points="192.92 327.18 207.23 358.8 229.64 363.25 192.92 327.18"
                   style="fill: rgb(64, 123, 255); opacity: 0.7; transform-origin: 211.28px 345.215px;"
                   class="animable"></polygon>
        </g>
      </g>
      <defs>
        <filter id="active" height="200%">
          <feMorphology in="SourceAlpha" result="DILATED" operator="dilate" radius="2"></feMorphology>
          <feFlood flood-color="#32DFEC" flood-opacity="1" result="PINK"></feFlood>
          <feComposite in="PINK" in2="DILATED" operator="in" result="OUTLINE"></feComposite>
          <feMerge>
            <feMergeNode in="OUTLINE"></feMergeNode>
            <feMergeNode in="SourceGraphic"></feMergeNode>
          </feMerge>
        </filter>
        <filter id="hover" height="200%">
          <feMorphology in="SourceAlpha" result="DILATED" operator="dilate" radius="2"></feMorphology>
          <feFlood flood-color="#ff0000" flood-opacity="0.5" result="PINK"></feFlood>
          <feComposite in="PINK" in2="DILATED" operator="in" result="OUTLINE"></feComposite>
          <feMerge>
            <feMergeNode in="OUTLINE"></feMergeNode>
            <feMergeNode in="SourceGraphic"></feMergeNode>
          </feMerge>
          <feColorMatrix type="matrix"
                         values="0   0   0   0   0                0   1   0   0   0                0   0   0   0   0                0   0   0   1   0 "></feColorMatrix>
        </filter>
      </defs>
    </svg>
  </div>
  <main v-else>
    <ul class="nav border-bottom px-3" v-if="routerPath !== '/login'">
      <li class="nav-item">
        <router-link :to="{name: 'flight_main'}" :class="{'nav-link': true, 'nav-disabled': disableLink}"
                     active-class="active">پرواز
        </router-link>
      </li>
      <li class="nav-item">
        <router-link :to="{name: 'tour_single'}" :class="{'nav-link': true, 'nav-disabled': disableLink}"
                     :disabled="disableLink" active-class="active">تور
          آماده
        </router-link>
      </li>
      <li class="nav-item">
        <router-link :to="{name: 'build_tour'}" :class="{'nav-link': true, 'nav-disabled': disableLink}"
                     :disabled="disableLink" active-class="active">تور دست
          ساز
        </router-link>
      </li>
      <li class="nav-item me-auto d-flex justify-content-between align-items-center">
        <p class="m-0">{{ username }}</p>
        <button class="btn text-danger" v-on:click="logout">
          <svg width="23" height="23" fill="currentColor" class="bi bi-power" viewBox="0 0 16 16">
            <path d="M7.5 1v7h1V1h-1z"/>
            <path
                d="M3 8.812a4.999 4.999 0 0 1 2.578-4.375l-.485-.874A6 6 0 1 0 11 3.616l-.501.865A5 5 0 1 1 3 8.812z"/>
          </svg>
        </button>
      </li>
    </ul>
    <router-view></router-view>
  </main>
</template>

<script>
import {router} from "@/routes";
import {toast} from "vue3-toastify";

export default {
  name: 'App',
  data() {
    return {
      loading: true
    }
  },
  computed: {
    username() {
      return this.$store.state.user.first_name + ' ' + this.$store.state.user.last_name;
    },
    routerPath() {
      return this.$route.path
    },
    disableLink() {
      return this.$store.state.disable_header_link
    }
  },
  methods: {
    logout() {
      localStorage.removeItem("access_token");
      this.$router.push('/login');
    }
  },
  created() {
    this.loading = true;
    this.$http.get('api/v1/user/profile/',).then((r) => {
      this.$store.state.user.profile = r.data.data;
      this.$store.state.user.first_name = r.data.data.first_name;
      this.$store.state.user.last_name = r.data.data.last_name;
      this.$router.push('/single');
      toast.success("خوش آمدید", {
        autoClose: 4000,
        position: "top-right",
        rtl: false,
        closeOnClick: true
      });
      this.loading = false;
    }).catch(() => {
      this.loading = false;
      return router.push('/login');
    })
  }
}
</script>

<style>
@import "assets/main.css";

.nav-link.active {
  background: rgba(105, 136, 180, 0.2);
  border-top-right-radius: 20px;
  border-top-left-radius: 20px;
}

.nav-disabled {
  opacity: 0.8;
  pointer-events: none;
}

</style>

<style scoped>
svg#freepik_stories-campfire:not(.animated) .animable {
  opacity: 0;
}

svg#freepik_stories-campfire.animated #freepik--Character--inject-1 {
  animation: 6s Infinite linear shake;
  animation-delay: 0s;
}

@keyframes shake {
  10%, 90% {
    transform: translate3d(-1px, 0, 0);
  }
  20%, 80% {
    transform: translate3d(2px, 0, 0);
  }
  30%, 50%, 70% {
    transform: translate3d(-4px, 0, 0);
  }
  40%, 60% {
    transform: translate3d(4px, 0, 0);
  }
}
</style>
